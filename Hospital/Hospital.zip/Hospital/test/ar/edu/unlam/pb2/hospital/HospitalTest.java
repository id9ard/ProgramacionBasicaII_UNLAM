package ar.edu.unlam.pb2.hospital;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class HospitalTest {

	@Test
	public void dadoQueExisteUnHospitalAlAgregarUnDoctorObtengoVerdadero() throws MatriculaDuplicadaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor = new Doctor(00000L, "Brossard", "Louis", fechaNacimiento);
		
		hospital.agregarDoctor(doctor);
		
		assertEquals(1, hospital.getDoctores().size());
	}
	
	@Test (expected = MatriculaDuplicadaException.class)
	public void dadoQueExisteUnHospitalConDoctoresAlAgregarUnDoctorConMatriculaDuplicadaSeLanzaUnaMatriculaDuplicadaException() throws MatriculaDuplicadaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor = new Doctor(00000L, "Brossard", "Louis", fechaNacimiento);
		
		hospital.agregarDoctor(doctor);
		hospital.agregarDoctor(doctor);
	}
	
	@Test 
	public void dadoQueExisteUnHospitalConDoctoresCuandoLosConosultoObtengoUnaColeccionDeDoctoresOrdenadasPorMatriculaAscendente() throws MatriculaDuplicadaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(00000L, "Brossard", "Louis", fechaNacimiento);
		Doctor doctor2 = new Doctor(00001L, "Brossard", "Louis", fechaNacimiento);
		Doctor doctor3 = new Doctor(00002L, "Brossard", "Louis", fechaNacimiento);
		
		hospital.agregarDoctor(doctor1);
		hospital.agregarDoctor(doctor2);
		hospital.agregarDoctor(doctor3);
		
		List<Doctor> doctoresOrdenados = hospital.obtenerDoctores();
		
		assertEquals(90000, doctoresOrdenados.get(0).getMatricula(), 0);
		assertEquals(90001, doctoresOrdenados.get(1).getMatricula(), 0);
		assertEquals(90002, doctoresOrdenados.get(2).getMatricula(), 0);
	}
	
	@Test 
	public void dadoQueExisteUnHospitalAlAgregarUnPacienteAfiliadoObtengoVerdadero() throws MatriculaDuplicadaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Paciente paciente = new Paciente(00000L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.AFILIACION_DIRECTA);
		hospital.agregarPaciente(paciente);
		
		assertEquals(1, hospital.getPacientes().size());

	}
	
	@Test 
	public void queSePuedaAgregarUnaAtencion() throws MatriculaDuplicadaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(00000L, "Brossard", "Louis", fechaNacimiento);
		hospital.agregarDoctor(doctor1);
		
		Paciente paciente1 = new Paciente(00002L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.AFILIACION_DIRECTA);
		hospital.agregarPaciente(paciente1);
		
		Atencion atencion = new Atencion(0L, doctor1, paciente1, "Motivo: desmayo");
		
		hospital.agregarAtencion(atencion);
		
		assertEquals(1, hospital.getAtenciones().size());

	}
	
	@Test 
	public void dadoQueExisteUnHospitalConDoctoresYPacientesCuandoQuieroDiagnosticarUnaAtencionDeUnDoctorObtengoVerdaderoYElDiagnosticoEnLaAtencionEstaActualizado() throws MatriculaDuplicadaException, TareaNoPermitidaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(00000L, "Brossard", "Louis", fechaNacimiento);
		hospital.agregarDoctor(doctor1);
		
		Paciente paciente1 = new Paciente(00002L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.AFILIACION_DIRECTA);
		hospital.agregarPaciente(paciente1);
		
		Atencion atencion = new Atencion(0L, doctor1, paciente1, "Motivo: desmayo");
		
		hospital.agregarAtencion(atencion);
		hospital.diagnosticarAtencion(atencion, doctor1, "Presion Alta");
		
		assertEquals("Presion Alta", hospital.getAtenciones().get(0).getDiagnostico());

	}
	
	@Test (expected = TareaNoPermitidaException.class)
	public void dadoQueExisteUnHospitalConDoctoresYPacientesCuandoQuieroDiagnosticarUnaAtencionQueNoEsDelDoctorSeLanzaUnaTareaNoPermitidaException() throws MatriculaDuplicadaException, TareaNoPermitidaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(000005L, "Brossard", "Louis", fechaNacimiento);
		Doctor doctor2 = new Doctor(000006L, "Brossard", "Louis", fechaNacimiento);
		hospital.agregarDoctor(doctor1);
		hospital.agregarDoctor(doctor2);
		
		Paciente paciente1 = new Paciente(00002L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.AFILIACION_DIRECTA);
		hospital.agregarPaciente(paciente1);
		
		Atencion atencion = new Atencion(0L, doctor1, paciente1, "Motivo: desmayo");
		
		hospital.agregarAtencion(atencion);
		hospital.diagnosticarAtencion(atencion, doctor2, "Presion Alta");
	}
	
	@Test 
	public void dadoQueExisteUnHospitalConDoctoresPacientesYAtencionesCuandoQuieroVerLasAtencionesAPacientesConObraSocialPorDoctorObtengoLasAtencionesParaEseDoctorDePacientesConObraSocial() throws MatriculaDuplicadaException, TareaNoPermitidaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(000005L, "Brossard", "Louis", fechaNacimiento);
		hospital.agregarDoctor(doctor1);
		
		Paciente paciente1 = new Paciente(000030L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.AFILIACION_DIRECTA);
		Paciente paciente2 = new Paciente(000040L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.OBRA_SOCIAL);
		Paciente paciente3 = new Paciente(000050L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.OBRA_SOCIAL);
		hospital.agregarPaciente(paciente1);
		hospital.agregarPaciente(paciente2);
		hospital.agregarPaciente(paciente3);
		
		Atencion atencion1 = new Atencion(1L, doctor1, paciente1, "Motivo: desmayo");
		Atencion atencion2 = new Atencion(2L, doctor1, paciente2, "Motivo: desmayo");
		Atencion atencion3 = new Atencion(3L, doctor1, paciente3, "Motivo: desmayo");
		
		hospital.agregarAtencion(atencion1);
		hospital.agregarAtencion(atencion2);
		hospital.agregarAtencion(atencion3);
		
		List<Atencion> atencionesObtenidas = hospital.obtenerAtencionesDePacientesConObraSocialAtendidasPorUnDoctor(doctor1.getMatricula());
		
		assertEquals(2, atencionesObtenidas.size());
	}
	
	@Test 
	public void dadoQueExisteUnHospitalCuandoConsultoElPrecioDeUnaAtencionParaUnPacienteAfiliadoObtengoElTotal500() throws MatriculaDuplicadaException, TareaNoPermitidaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(000005L, "Brossard", "Louis", fechaNacimiento);
		hospital.agregarDoctor(doctor1);
		
		Paciente paciente1 = new Paciente(000030L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.AFILIACION_DIRECTA);
		hospital.agregarPaciente(paciente1);
		
		Atencion atencion1 = new Atencion(1L, doctor1, paciente1, "Motivo: desmayo");
		hospital.agregarAtencion(atencion1);

		assertEquals(500.0, hospital.consultarPrecioAtencion(paciente1), 0);
		
	}
	
	@Test 
	public void dadoQueExisteUnHospitalCuandoConsultoLaFacturacionDeCadaDoctorObtengoUnMapaPorDoctorYTotalOrdenadoPorMatriculaDeDoctorDescendente() throws MatriculaDuplicadaException, TareaNoPermitidaException {
		Hospital hospital = new Hospital();
		LocalDate fechaNacimiento = LocalDate.of(1996, 5, 5);
		
		Doctor doctor1 = new Doctor(000001L, "Brossard", "Louis", fechaNacimiento);
		Doctor doctor2 = new Doctor(000002L, "Brossard", "Louis", fechaNacimiento);
		Doctor doctor3 = new Doctor(000003L, "Brossard", "Louis", fechaNacimiento);
		hospital.agregarDoctor(doctor1);
		hospital.agregarDoctor(doctor2);
		hospital.agregarDoctor(doctor3);
		
		Paciente paciente1 = new Paciente(100L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.PARTICULAR);
		Paciente paciente2 = new Paciente(101L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.PARTICULAR);
		Paciente paciente3 = new Paciente(102L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.PARTICULAR);
		Paciente paciente4 = new Paciente(103L, "Brossard", "Louis", fechaNacimiento, TipoDePaciente.PARTICULAR);
		hospital.agregarPaciente(paciente1);
		hospital.agregarPaciente(paciente2);
		hospital.agregarPaciente(paciente3);
		hospital.agregarPaciente(paciente4);
		
		Atencion atencion1 = new Atencion(1L, doctor1, paciente1, "Motivo: desmayo");
		Atencion atencion2 = new Atencion(2L, doctor1, paciente2, "Motivo: desmayo");
		Atencion atencion3 = new Atencion(3L, doctor1, paciente3, "Motivo: desmayo");
		Atencion atencion4 = new Atencion(4L, doctor1, paciente4, "Motivo: desmayo");
		hospital.agregarAtencion(atencion1);
		hospital.agregarAtencion(atencion2);
		hospital.agregarAtencion(atencion3);
		hospital.agregarAtencion(atencion4);
		
		
		Map<Doctor, Double> facturacionPorDoctor = hospital.obtenerFacturacionDeAtencionesPorDoctor();

		assertEquals(3, facturacionPorDoctor.size());
		assertEquals(4000.0, facturacionPorDoctor.get(doctor1), 0);
	}

}
