package ar.edu.unlam.pb2.hospital;

public enum TipoDePaciente {
	OBRA_SOCIAL, AFILIACION_DIRECTA, PARTICULAR
}
