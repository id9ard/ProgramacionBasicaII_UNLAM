package ar.edu.unlam.pb2.hospital;

import java.time.LocalDate;
import java.util.Objects;

public class Persona {
	private Long dNI;
	private String apellido;
	private String nombre;
	private LocalDate fechaDeNacimiento;
	public Persona(Long dNI, String apellido, String nombre, LocalDate fechaDeNacimiento) {
		this.dNI = dNI;
		this.apellido = apellido;
		this.nombre = nombre;
		this.fechaDeNacimiento = fechaDeNacimiento;
	}
	@Override
	public int hashCode() {
		return Objects.hash(dNI);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return Objects.equals(dNI, other.dNI);
	}
	
}
