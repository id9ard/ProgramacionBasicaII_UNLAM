package ar.edu.unlam.pb2.hospital;

import java.time.LocalDate;

public class Doctor extends Persona implements Comparable<Doctor>{
	private Long matricula;

	public Doctor(Long dNI, String apellido, String nombre, LocalDate fechaDeNacimiento) {
		super(dNI, apellido, nombre, fechaDeNacimiento);
		this.matricula = Hospital.generarMatricula();
	}

	@Override
	public int compareTo(Doctor o) {
		return this.matricula.compareTo(o.getMatricula());
	}

	public Long getMatricula() {
		return matricula;
	}
}