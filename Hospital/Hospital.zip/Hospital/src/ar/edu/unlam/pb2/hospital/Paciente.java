package ar.edu.unlam.pb2.hospital;

import java.time.LocalDate;

public class Paciente extends Persona {
	private Long legajo;
	private TipoDePaciente tipoDePaciente;
	
	public Paciente(Long dNI, String apellido, String nombre, LocalDate fechaDeNacimiento, TipoDePaciente tipoDePaciente) {
		super(dNI, apellido, nombre, fechaDeNacimiento);
		this.tipoDePaciente = tipoDePaciente;
	}

	public TipoDePaciente getTipoDePaciente() {
		return tipoDePaciente;
	}

}
