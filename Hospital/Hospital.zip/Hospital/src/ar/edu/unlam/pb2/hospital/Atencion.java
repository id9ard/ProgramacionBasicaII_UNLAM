package ar.edu.unlam.pb2.hospital;

import java.util.Objects;

public class Atencion {
	private Long numeroAtencion;
	
	private Doctor doctor;
	private Paciente paciente;
	private String motivoVisita;
	private String diagnostico;
	
	private Double precio;

	public Atencion(Long numeroAtencion, Doctor doctor, Paciente paciente, String motivoVisita) {
		super();
		this.numeroAtencion = numeroAtencion;
		this.doctor = doctor;
		this.paciente = paciente;
		this.motivoVisita = motivoVisita;
	}

	public String getDiagnostico() {
		return diagnostico;
	}

	public Doctor getDoctor() {
		return doctor;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setDiagnostico(String diagnostico) {
		this.diagnostico = diagnostico;
	}

	@Override
	public int hashCode() {
		return Objects.hash(numeroAtencion);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Atencion other = (Atencion) obj;
		return Objects.equals(numeroAtencion, other.numeroAtencion);
	}

}
