package ar.edu.unlam.pb2.hospital;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class Hospital {
	
	private static Long matriculaDoctor;
	private Set<Doctor> doctores = new TreeSet<Doctor>();
	private Set<Paciente> pacientes = new HashSet<Paciente>();
	
	private List<Atencion> atenciones = new LinkedList<Atencion>();
	
	private Double precioBase = 1000.0;
	private Double descuentoObraSocial = 200.0; 
	private Double porcentajeAfiliado = 0.5;
	
	public Hospital() {
		matriculaDoctor = 90000L;
	}
	
	public Set<Doctor> getDoctores() {
		return doctores;
	}
	
	public Set<Paciente> getPacientes() {
		return pacientes;
	}
	
	public List<Atencion> getAtenciones() {
		return atenciones;
	}

	public static Long generarMatricula() {
		return matriculaDoctor++;
	}

	public void agregarDoctor(Doctor doctor) throws MatriculaDuplicadaException {
		if(!this.doctores.contains(doctor)) {			
			this.doctores.add(doctor);
		} else {
			throw new MatriculaDuplicadaException("El doctor ya se encuentra registrado");
		}
	}
	
	public void agregarPaciente(Paciente paciente) {
		this.pacientes.add(paciente);
	}
	
	public void agregarAtencion(Atencion atencion) {
		this.atenciones.add(atencion);
	}

	public void diagnosticarAtencion(Atencion atencion, Doctor doctor, String diagnostico) throws TareaNoPermitidaException {
		if(this.atenciones.contains(atencion)) {
			if(atencion.getDoctor().equals(doctor)) {
				atencion.setDiagnostico(diagnostico);
			} else {
				throw new TareaNoPermitidaException("No se puede diagnosticar");
			}
		} 
	}

	public List<Doctor> obtenerDoctores() {
		List<Doctor> doctoresOrdenados = new LinkedList<Doctor>(this.getDoctores());
		Collections.sort(doctoresOrdenados);
		return doctoresOrdenados;
	}

	public List<Atencion> obtenerAtencionesDePacientesConObraSocialAtendidasPorUnDoctor(Long matricula) {
		List<Atencion> atencionesObtenidas = new LinkedList<Atencion>();
		for(Atencion atencionObtenida : this.atenciones) {
			if(atencionObtenida.getDoctor().getMatricula() == matricula &&
					atencionObtenida.getPaciente().getTipoDePaciente() == TipoDePaciente.OBRA_SOCIAL) {
				atencionesObtenidas.add(atencionObtenida);
			}
		}
		return atencionesObtenidas;
	}

	public Double consultarPrecioAtencion(Paciente paciente) {
		Double precio = this.precioBase;
		if(paciente.getTipoDePaciente() == TipoDePaciente.OBRA_SOCIAL) {
			precio -= this.descuentoObraSocial;
		} else if(paciente.getTipoDePaciente() == TipoDePaciente.AFILIACION_DIRECTA) {
			precio -= (precio * this.porcentajeAfiliado);
		}
		return precio;
	}

	public Map<Doctor, Double> obtenerFacturacionDeAtencionesPorDoctor() {
		Map<Doctor, Double> facturacionesObtenidasPorDoctor = new HashMap<Doctor, Double>();
		
		for(Doctor doctorObtenido : this.doctores) {
			Double precioAcumulado = 0.0;
			for(Atencion atencionsObtenida : this.atenciones) {
				if(doctorObtenido.equals(atencionsObtenida.getDoctor())) {
					precioAcumulado += this.consultarPrecioAtencion(atencionsObtenida.getPaciente());
				}
			}
			facturacionesObtenidasPorDoctor.put(doctorObtenido, precioAcumulado);
		}
		
		return facturacionesObtenidasPorDoctor;
	}

}
