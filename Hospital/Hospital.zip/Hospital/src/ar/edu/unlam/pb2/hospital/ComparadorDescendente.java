package ar.edu.unlam.pb2.hospital;

import java.util.Comparator;

public class ComparadorDescendente implements Comparator<Doctor> {
	@Override
	public int compare(Doctor o1, Doctor o2) {
		return o2.getMatricula().compareTo(o1.getMatricula());
	}

}
