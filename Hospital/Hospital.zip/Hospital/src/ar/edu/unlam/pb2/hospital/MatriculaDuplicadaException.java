package ar.edu.unlam.pb2.hospital;

public class MatriculaDuplicadaException extends Exception {
	private static final long serialVersionUID = 1L;

	public MatriculaDuplicadaException(String mensaje) {
		super(mensaje);
	}

}
