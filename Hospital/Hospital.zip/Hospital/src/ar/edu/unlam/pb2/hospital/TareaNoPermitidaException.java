package ar.edu.unlam.pb2.hospital;

public class TareaNoPermitidaException extends Exception {
	private static final long serialVersionUID = 1L;
	public TareaNoPermitidaException(String mensaje) {
		super(mensaje);
	}

}
