package ar.edu.unlam.pb2.copasDelMundo;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Fabrica {
	private Double MANO_DE_OBRA = 100.0;
	
	List<Copa> copas = new LinkedList<Copa>();
	Set<Cliente> clientes = new TreeSet<Cliente>();
	
	Set<Venta> ventas = new HashSet<Venta>();

	public void agregarCopa(Copa copa) {
		this.copas.add(copa);
	}

	public List<Copa> getCopas() {
		return copas;
	}

	public void agregarCliente(Cliente cliente) throws ClienteDuplicadoException {
		if(!this.clientes.contains(cliente)) {
			this.clientes.add(cliente);
		} else {
			throw new ClienteDuplicadoException("Cliente duplicado");
		}
	}

	public Set<Cliente> getClientes() {
		return clientes;
	}

	public List<Copa> obtenerCopasDelMundoEstandar() {
		List<Copa> copasObtenidas = new LinkedList<Copa>();
		for(Copa copaObtenida : this.copas) {
			if(copaObtenida instanceof CopaEstandar) {
				copasObtenidas.add(copaObtenida);
			}
		}
		return copasObtenidas;
	}

	public Copa obtenerCopaDelMundoPorId(Integer id) throws CopaDelMundoEncontradaException {
		for(Copa copaObtenida : this.copas) {
			if(copaObtenida.getIdentificador() == id) {
				return copaObtenida;
			} else {
				throw new CopaDelMundoEncontradaException("No se encuentra la copa buscada");
			}
		}
		return null;
	}

	public void agregarVenta(Cliente cliente, Copa copaParametro, Integer cantidad) {
		for(Copa copaObtenida : this.copas) {
			if(this.copas.contains(copaObtenida) && copaParametro instanceof CopaEstandar) {
				CopaEstandar copaNueva = new CopaEstandar(copaParametro.getIdentificador(), copaParametro.getMaterial(), cantidad);
				Venta ventaNueva = new Venta(cliente);
				ventaNueva.getCopas().add(copaNueva);
				this.ventas.add(ventaNueva);
				((CopaEstandar) copaParametro).setStock(((CopaEstandar) copaParametro).getStock() - cantidad);;
			}
		}
	}

	public Set<Venta> getVentas() {
		return ventas;
	}

	public Double calcularPrecioCopaPersonalizada(Copa copa) {
		return this.MANO_DE_OBRA + (this.MANO_DE_OBRA * copa.getPrecio());
	}
	
}
