package ar.edu.unlam.pb2.copasDelMundo;

public abstract class Copa {
	private Material material;
	private Integer identificador;
	private Double precio;
	public Copa(Integer identificador ,Material material) {
		this.material = material;
		this.identificador = identificador;
	}
	public abstract Double getPrecio();
	public Integer getIdentificador() {
		return identificador;
	}
	public Material getMaterial() {
		return material;
	}
	
}
