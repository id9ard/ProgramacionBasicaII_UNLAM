package ar.edu.unlam.pb2.copasDelMundo;

public enum Material {
	PLASTICO, YESO , RESINA
}
