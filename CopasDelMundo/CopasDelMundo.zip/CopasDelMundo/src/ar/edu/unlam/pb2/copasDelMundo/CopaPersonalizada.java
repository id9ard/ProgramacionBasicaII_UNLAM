package ar.edu.unlam.pb2.copasDelMundo;

public class CopaPersonalizada extends Copa {
	private Color color;

	public CopaPersonalizada(Integer identificador ,Material material, Color color) {
		super(identificador ,material);
		this.color = color;
	}

	@Override
	public Double getPrecio() {
		Double porcentaje = 0.15;
		if(this.color == color.CAOBA) {
			porcentaje += 0.05;
		} else if(this.color == color.CEDRO) {
			porcentaje += 0.10;
		} else if(this.color == color.ROBLE_OSCURO) {
			porcentaje += 0.15;
		}
		return porcentaje;
	}

}
