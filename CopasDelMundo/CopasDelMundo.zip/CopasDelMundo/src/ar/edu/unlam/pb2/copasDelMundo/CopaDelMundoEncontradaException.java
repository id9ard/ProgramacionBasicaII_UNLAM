package ar.edu.unlam.pb2.copasDelMundo;

public class CopaDelMundoEncontradaException extends Exception {
	private static final long serialVersionUID = 1L;
	public CopaDelMundoEncontradaException(String mensaje) {
		super(mensaje);
	}


}
