package ar.edu.unlam.pb2.copasDelMundo;

import java.util.Objects;

public class Cliente implements Comparable<Cliente>{
	private Integer dNI;
	private String apllido;
	private String nombre;
	
	public Cliente(Integer dNI, String apllido, String nombre) {
		this.dNI = dNI;
		this.apllido = apllido;
		this.nombre = nombre;
	}

	@Override
	public int hashCode() {
		return Objects.hash(dNI);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente other = (Cliente) obj;
		return Objects.equals(dNI, other.dNI);
	}

	public Integer getdNI() {
		return dNI;
	}

	@Override
	public int compareTo(Cliente o) {
		return this.dNI.compareTo(o.getdNI());
	}
	
}
