package ar.edu.unlam.pb2.copasDelMundo;

public class CopaEstandar extends Copa {
	private Integer stock;
	
	public CopaEstandar(Integer identificador ,Material material,Integer stock) {
		super(identificador ,material);
		this.stock = stock;
	}

	@Override
	public Double getPrecio() {
		return 0.20;
	}

	public Integer getStock() {
		return stock;
	}

	public void setStock(Integer stock) {
		this.stock = stock;
	}


}
