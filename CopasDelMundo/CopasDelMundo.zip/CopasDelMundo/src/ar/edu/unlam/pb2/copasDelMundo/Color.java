package ar.edu.unlam.pb2.copasDelMundo;

public enum Color {
	CAOBA, CEDRO , ROBLE_OSCURO
}
