package ar.edu.unlam.pb2.copasDelMundo;

import static org.junit.Assert.*;

import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

public class FabricaTest {

	@Test
	public void dadoQueExisteUnaFabricaDeCopasDelMundoSePuedeAgregarUnaCopaDelMundoEstandar() {
		Fabrica fabrica = new Fabrica();
		CopaEstandar copaEstandar = new CopaEstandar(0000, Material.PLASTICO, 100);
		
		fabrica.agregarCopa(copaEstandar);
		
		assertEquals(1, fabrica.getCopas().size());
	}
	
	@Test
	public void dadoQueExisteUnaFabricaDeCopasDelMundoSePuedeAgregarUnaCopaDelMundoPersonalizada() {
		Fabrica fabrica = new Fabrica();
		CopaPersonalizada copaPersonalizada= new CopaPersonalizada (0000, Material.PLASTICO, Color.CAOBA);
		
		fabrica.agregarCopa(copaPersonalizada);
		
		assertEquals(1, fabrica.getCopas().size());
	}
	
	
	@Test (expected = ClienteDuplicadoException.class)
	public void dadoQueExisteUnaFabricaDeCopasDelMundoAlAgregarUnClienteExistenteSeLanzaUnaClienteDuplicadoException() throws ClienteDuplicadoException {
		Fabrica fabrica = new Fabrica();
		Cliente cliente = new Cliente(000000, "Brossard", "Louis");
		Cliente clienteDuplicado = new Cliente(000000, "Brossard", "Louis");
		
		fabrica.agregarCliente(cliente);
		fabrica.agregarCliente(clienteDuplicado);
	}
	
	@Test 
	public void dadoQueExisteUnaFabricaQuePoseeCopasDelMundoSePuedenObtenerLasCopasDelMundoEstandar() throws ClienteDuplicadoException {
		Fabrica fabrica = new Fabrica();
		CopaEstandar copaEstandar1 = new CopaEstandar(0000, Material.PLASTICO, 100);
		CopaEstandar copaEstandar2 = new CopaEstandar(0001, Material.PLASTICO, 100);
		CopaPersonalizada copaPersonalizada= new CopaPersonalizada (0002, Material.PLASTICO, Color.CAOBA);
		
		fabrica.agregarCopa(copaEstandar1);
		fabrica.agregarCopa(copaEstandar2);
		fabrica.agregarCopa(copaPersonalizada);
		
		List<Copa> copasDelMundoEstandar = fabrica.obtenerCopasDelMundoEstandar();
		
		assertEquals(2, copasDelMundoEstandar.size());
	}
	
	@Test (expected = CopaDelMundoEncontradaException.class)
	public void dadoQueExisteUnaFabricaDeCopasDelMundoConCopasDelMundoPuedoObtenerUnaCopaDelMundoPorSuId() throws ClienteDuplicadoException, CopaDelMundoEncontradaException {
		Fabrica fabrica = new Fabrica();
		CopaEstandar copaEstandar1 = new CopaEstandar(0000, Material.PLASTICO, 100);
		CopaEstandar copaEstandar2 = new CopaEstandar(0001, Material.PLASTICO, 100);
		
		fabrica.agregarCopa(copaEstandar1);
		fabrica.agregarCopa(copaEstandar2);
		
		Copa copaDelMundo = fabrica.obtenerCopaDelMundoPorId(0001);
		
		assertEquals(00001, copaDelMundo.getIdentificador(), 0);
	}
	
	@Test 
	public void dadoQueExisteUnaFabricaDeCopasDelMundoConCopasDelMundoSeLanceUnaExcepcionSiNoEncuentraLaCopaDelMundo() throws ClienteDuplicadoException, CopaDelMundoEncontradaException {
		Fabrica fabrica = new Fabrica();
		CopaEstandar copaEstandar1 = new CopaEstandar(0000, Material.PLASTICO, 100);
		CopaEstandar copaEstandar2 = new CopaEstandar(0001, Material.PLASTICO, 100);
		
		fabrica.agregarCopa(copaEstandar1);
		fabrica.agregarCopa(copaEstandar2);
		
		fabrica.obtenerCopaDelMundoPorId(0000);
	}
	
	@Test 
	public void dadoQueExisteUnaFabricaDeCopasDelMundoConCopasDelMundoAlAgregarCincoCopasDelMundoAUnaVentaDeCopasDelMundoEstandarParaUnClienteSeDescuentanCincoUnidadesDelStockDeCopasDelMundoEstandar() throws ClienteDuplicadoException {
		Fabrica fabrica = new Fabrica();
		CopaEstandar copaEstandar1 = new CopaEstandar(0000, Material.PLASTICO, 100);
		Cliente cliente = new Cliente(000000, "Brossard", "Louis");
		
		fabrica.agregarCopa(copaEstandar1);
		fabrica.agregarVenta(cliente, copaEstandar1 , 10);
		
		List<Venta> ventasCasteadas = new LinkedList<Venta>(fabrica.getVentas());
		CopaEstandar copa = null; 
		for(Venta ventaObtenida : ventasCasteadas) {
			copa = (CopaEstandar) ventaObtenida.getCopas().get(0);
		}
		
		assertEquals(90, copaEstandar1.getStock() , 0);
		assertEquals(10, copa.getStock(), 0);
		
	}
	
	@Test 
	public void dadoQueExisteUnaFabricaDeCopasDelMundoConCopasDelMundoPersonalizadasSePuedeObtenerElPrecioDeUnaCopaDelMundoPersonalizada() throws ClienteDuplicadoException {
		Fabrica fabrica = new Fabrica();
		CopaPersonalizada copaPersonalizada= new CopaPersonalizada(0000, Material.PLASTICO, Color.ROBLE_OSCURO);
		
		fabrica.agregarCopa(copaPersonalizada);
		
		assertEquals(130, fabrica.calcularPrecioCopaPersonalizada(copaPersonalizada), 0);
		
	}
	
	@Test 
	public void dadoQueExisteUnaFabricaDeCopasDelMundoConVentasDeCopasDelMundoEstandarYPersonalizadasVendidasAClientesSePuedeObtenerUnMapaConClaveClienteYTotalDeVentasDeCopasEstandarOrdenadoPorCliente () throws ClienteDuplicadoException {
		Fabrica fabrica = new Fabrica();
		CopaPersonalizada copaPersonalizada= new CopaPersonalizada(0000, Material.PLASTICO, Color.ROBLE_OSCURO);
		
		fabrica.agregarCopa(copaPersonalizada);
		
		assertEquals(130, fabrica.calcularPrecioCopaPersonalizada(copaPersonalizada), 0);
		
	}

}
