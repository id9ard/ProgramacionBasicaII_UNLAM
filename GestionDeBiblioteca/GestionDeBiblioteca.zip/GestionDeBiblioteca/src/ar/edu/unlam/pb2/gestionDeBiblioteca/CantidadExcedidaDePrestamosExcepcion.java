package ar.edu.unlam.pb2.gestionDeBiblioteca;

public class CantidadExcedidaDePrestamosExcepcion extends Exception {
	private static final long serialVersionUID = 1L;
	public CantidadExcedidaDePrestamosExcepcion(String mensaje) {
		super(mensaje);
	}
}
