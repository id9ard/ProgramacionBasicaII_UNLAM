package ar.edu.unlam.pb2.gestionDeBiblioteca;

public class Profesor extends Usuario {
	public Profesor(String nombre, Long numeroUsuario) {
		super(nombre, numeroUsuario);
	}

	@Override
	public Integer getCantidadPrestamos() {
		return 3;
	}
}
