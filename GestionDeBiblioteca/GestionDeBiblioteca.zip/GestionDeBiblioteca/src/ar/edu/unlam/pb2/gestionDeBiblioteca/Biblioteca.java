package ar.edu.unlam.pb2.gestionDeBiblioteca;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class Biblioteca {
	List<Libro> libros = new LinkedList<Libro>();
	Set<Prestamo>historialPrestamos = new HashSet<Prestamo>();

	public void agregarLibro(Libro libro) {
		if(!libros.contains(libro)) {			
			libros.add(libro);
		}
	}

	public List<Libro> getLibros() {
		return libros;
	}

	public void prestarLibro(Usuario usuario, Libro libro, LocalDate fechaPrestamo) throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion {
		Prestamo prestamo = new Prestamo(usuario, libro, fechaPrestamo);
		if(!this.historialPrestamos.contains(prestamo)) {
			if(librosPorUsuario(usuario) < usuario.getCantidadPrestamos()) {				
				this.historialPrestamos.add(prestamo);
				libro.setEstaDisponible(false);
			} else {
				throw new CantidadExcedidaDePrestamosExcepcion("Acaba de exceder el limite maximo de prestamos permitidos");
			}
		} else {
			throw new LibroPrestadoExcepcion("El libro ya se encuentra prestado");
		}
	}

	public Set<Prestamo> getPrestamos() {
		return historialPrestamos;
	}
	
	private Integer librosPorUsuario(Usuario usuario) {
		Integer cantidadLibros = 0;
		for(Prestamo usuarioEncontrado : this.historialPrestamos) {
			if(usuarioEncontrado.getUsuario().equals(usuario)) {
				cantidadLibros++;
			}
		}
		return cantidadLibros;
	}

	public void devolverLibro(Usuario usuario, Libro libro, LocalDate fechaPrestamo) throws LibroNoPrestadoExcepcion {
		Prestamo prestamo = new Prestamo(usuario, libro, fechaPrestamo);
		if(this.historialPrestamos.contains(prestamo)) {
			this.historialPrestamos.remove(prestamo);
			libro.setEstaDisponible(true);
		} else {
			throw new LibroNoPrestadoExcepcion("No se puede devolver el libro");
		}
	}

}
