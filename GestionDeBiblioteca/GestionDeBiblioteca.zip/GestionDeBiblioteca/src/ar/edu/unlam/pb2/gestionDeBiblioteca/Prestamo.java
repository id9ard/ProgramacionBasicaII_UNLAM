package ar.edu.unlam.pb2.gestionDeBiblioteca;

import java.time.LocalDate;
import java.util.Objects;

public class Prestamo {
	private Usuario usuario;
	private Libro libro;
	private LocalDate fechaPrestamo;
	private LocalDate fechaDevolucion;
	public Prestamo(Usuario usuario , Libro libro, LocalDate fechaPrestamo) {
		this.usuario = usuario;
		this.libro = libro;
		this.fechaPrestamo = fechaPrestamo;
		this.fechaDevolucion = fechaPrestamo.plusDays(10);
	}
	@Override
	public int hashCode() {
		return Objects.hash(libro);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Prestamo other = (Prestamo) obj;
		return Objects.equals(libro, other.libro);
	}
	public Usuario getUsuario() {
		return usuario;
	}
	
}