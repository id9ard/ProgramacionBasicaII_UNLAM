package ar.edu.unlam.pb2.gestionDeBiblioteca;

public class LibroPrestadoExcepcion extends Exception {
	private static final long serialVersionUID = 1L;
	public LibroPrestadoExcepcion(String mensaje) {
		super(mensaje);
	}
}
