package ar.edu.unlam.pb2.gestionDeBiblioteca;

import java.util.Objects;

public class Libro {
	
	private String titulo;
	private String autor;
	private Long iSBN;
	
	private boolean estaDisponible;

	public Libro(String titulo, String autor, Long iSBN) {
		this.titulo = titulo;
		this.autor = autor;
		this.iSBN = iSBN;
		this.estaDisponible = true;
	}

	@Override
	public int hashCode() {
		return Objects.hash(iSBN);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Libro other = (Libro) obj;
		return Objects.equals(iSBN, other.iSBN);
	}

	public boolean isEstaDisponible() {
		return estaDisponible;
	}

	public void setEstaDisponible(boolean estaDisponible) {
		this.estaDisponible = estaDisponible;
	}
	
}
