package ar.edu.unlam.pb2.gestionDeBiblioteca;

public class Estudiante extends Usuario {
	public Estudiante(String nombre, Long numeroUsuario) {
		super(nombre, numeroUsuario);
	}

	@Override
	public Integer getCantidadPrestamos() {
		return 1;
	}
}
