package ar.edu.unlam.pb2.gestionDeBiblioteca;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Test;

public class BibliotecaTest {

	@Test
	public void queSePuedaAgregarUnLibroALaBiblioteca() {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		
		biblioteca.agregarLibro(libro);
		
		assertEquals(1, biblioteca.getLibros().size());
	}
	
	@Test
	public void queNoSePuedaAgregarLibrosDuplicadosALaBiblioteca() {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Libro libro1 = new Libro(null, null, 00000L);
		
		biblioteca.agregarLibro(libro);
		biblioteca.agregarLibro(libro1);
		
		assertEquals(1, biblioteca.getLibros().size());
	}
	

	@Test
	public void queSePuedaPrestarUnLibroAUnEstudiante() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Estudiante estudiante = new Estudiante("Louis", 999L); 
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.prestarLibro(estudiante , libro, fechaPrestamo);
		
		assertEquals(1, biblioteca.getPrestamos().size());
	}
	
	@Test
	public void queAlPrestarUnLibroaUnEstudianteCambieSuEstadoAFalse() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Estudiante estudiante = new Estudiante("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.prestarLibro(estudiante , libro, fechaPrestamo);

		
		assertFalse(biblioteca.getLibros().get(0).isEstaDisponible());
	}
	
	@Test
	public void queSoloSePuedaPrestarUnLibroALaVezAUnEstudiante() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Libro libro1 = new Libro(null, null, 00001L);
		Estudiante estudiante = new Estudiante("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.agregarLibro(libro1);
		biblioteca.prestarLibro(estudiante , libro, fechaPrestamo);
		
		assertEquals(1, biblioteca.getPrestamos().size());
	}
	
	@Test
	public void queSoloSePuedaPrestarUnMAximoDeTresLibrosALaVezAUnProfesor() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Libro libro1 = new Libro(null, null, 00001L);
		Libro libro2 = new Libro(null, null, 00002L);
		Libro libro3 = new Libro(null, null, 00003L);
		Profesor profesor = new Profesor("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.agregarLibro(libro1);
		biblioteca.agregarLibro(libro2);
		biblioteca.agregarLibro(libro3);
		
		biblioteca.prestarLibro(profesor , libro, fechaPrestamo);
		biblioteca.prestarLibro(profesor , libro1, fechaPrestamo);
		biblioteca.prestarLibro(profesor , libro2, fechaPrestamo);

		assertEquals(3, biblioteca.getPrestamos().size());
	}
	
	@Test
	public void queSePuedaDevolverUnLibroPrestado() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion, LibroNoPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Profesor profesor = new Profesor("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.prestarLibro(profesor , libro, fechaPrestamo);
		biblioteca.devolverLibro(profesor , libro, fechaPrestamo);

		
		assertEquals(0, biblioteca.getPrestamos().size());
	}
	
	@Test
	public void queCambieElEstadoALibroDisponibleDespuesDeSerDevuelto() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion, LibroNoPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Profesor profesor = new Profesor("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.prestarLibro(profesor , libro, fechaPrestamo);
		biblioteca.devolverLibro(profesor , libro, fechaPrestamo);

		assertTrue(biblioteca.getLibros().get(0).isEstaDisponible());
	}
	
	@Test (expected = CantidadExcedidaDePrestamosExcepcion.class)
	public void queSeLanceUnaExcepcionSiSeIntentaPrestarMasLibrosDeLosPermitidos() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Libro libro1 = new Libro(null, null, 00001L);
		Libro libro2 = new Libro(null, null, 00002L);
		Libro libro3 = new Libro(null, null, 00003L);
		Profesor profesor = new Profesor("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.agregarLibro(libro1);
		biblioteca.agregarLibro(libro2);
		biblioteca.agregarLibro(libro3);
		
		biblioteca.prestarLibro(profesor , libro, fechaPrestamo);
		biblioteca.prestarLibro(profesor , libro1, fechaPrestamo);
		biblioteca.prestarLibro(profesor , libro2, fechaPrestamo);
		biblioteca.prestarLibro(profesor , libro3, fechaPrestamo);
	}
	
	@Test (expected = LibroPrestadoExcepcion.class)
	public void queLanceUnaExcepcionSiSeIntentaPrestarUnLibroNoDisponible() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion, LibroNoPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Profesor profesor = new Profesor("Louis", 999L);
		Profesor profesor1 = new Profesor("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		
		biblioteca.prestarLibro(profesor , libro, fechaPrestamo);
		biblioteca.prestarLibro(profesor1 , libro, fechaPrestamo);
	}
	
	@Test (expected = LibroNoPrestadoExcepcion.class)
	public void queLanceUnaExcepcionSiSeIntentaDevolverUnLibroQueNoHaSidoPrestado() throws CantidadExcedidaDePrestamosExcepcion, LibroPrestadoExcepcion, LibroNoPrestadoExcepcion {
		Biblioteca biblioteca = new Biblioteca();
		Libro libro = new Libro("Cien años de Soledad", "Gabo", 00000L);
		Profesor profesor = new Profesor("Louis", 999L);
		
		LocalDate fechaPrestamo = LocalDate.now();
		
		biblioteca.agregarLibro(libro);
		biblioteca.devolverLibro(profesor , libro, fechaPrestamo);
	}

}
