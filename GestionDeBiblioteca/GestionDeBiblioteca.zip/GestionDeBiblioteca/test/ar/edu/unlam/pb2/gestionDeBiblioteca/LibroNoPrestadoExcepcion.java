package ar.edu.unlam.pb2.gestionDeBiblioteca;

public class LibroNoPrestadoExcepcion extends Exception {
	private static final long serialVersionUID = 1L;
	public LibroNoPrestadoExcepcion(String mensaje) {
		super(mensaje);
	}
}
