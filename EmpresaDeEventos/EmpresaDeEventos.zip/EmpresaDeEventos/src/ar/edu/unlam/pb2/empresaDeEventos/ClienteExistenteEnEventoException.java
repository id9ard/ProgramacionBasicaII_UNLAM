package ar.edu.unlam.pb2.empresaDeEventos;

public class ClienteExistenteEnEventoException extends Exception {

	private static final long serialVersionUID = 1L;
	public ClienteExistenteEnEventoException(String mensaje) {
		super(mensaje);
	}


}
