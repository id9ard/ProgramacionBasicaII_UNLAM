package ar.edu.unlam.pb2.empresaDeEventos;

public enum Sala {
	CHICA, MEDIANA, GRANDE
}
