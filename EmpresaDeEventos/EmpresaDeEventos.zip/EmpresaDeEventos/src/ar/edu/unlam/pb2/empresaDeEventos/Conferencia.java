package ar.edu.unlam.pb2.empresaDeEventos;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

public class Conferencia extends Evento{
	private Set<String> temas = new HashSet<String>();

	public Conferencia(String codigo, String nombre, LocalDate fecha, Sala sala, Persona expositor) {
		super(codigo, nombre, fecha, sala, expositor);
	}

	@Override
	public Double getValorPorPersona() {
		return 15000.0;
	}
	
}
