package ar.edu.unlam.pb2.empresaDeEventos;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public abstract class Evento {
	private String codigo;
	private String nombre;
	private LocalDate fecha;
	private Sala sala;
	
	private Persona expositor;
	private List<Persona> participantes = new LinkedList<Persona>();
	
	private Double valorPorPersona;
	
	
	public Evento(String codigo, String nombre, LocalDate fecha, Sala sala, Persona expositor) {
		this.codigo = codigo;
		this.nombre = nombre;
		this.fecha = fecha;
		this.sala = sala;
		this.expositor = expositor;
	}

	public List<Persona> getParticipantes() {
		return participantes;
	}

	public abstract Double getValorPorPersona();

	@Override
	public int hashCode() {
		return Objects.hash(codigo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Evento other = (Evento) obj;
		return Objects.equals(codigo, other.codigo);
	}

	public String getCodigo() {
		return codigo;
	}
	
}
