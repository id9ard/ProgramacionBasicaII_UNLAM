package ar.edu.unlam.pb2.empresaDeEventos;

import java.util.Objects;

public class Persona implements Comparable<Persona>{
	private String dNI;
	private String nombre;
	private String apellido;
	public Persona(String dNI, String nombre, String apellido) {
		this.dNI = dNI;
		this.nombre = nombre;
		this.apellido = apellido;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(dNI);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Persona other = (Persona) obj;
		return Objects.equals(dNI, other.dNI);
	}

	public String getApellido() {
		return apellido;
	}

	@Override
	public int compareTo(Persona o) {
		return this.apellido.compareTo(o.getApellido());
	}

}
