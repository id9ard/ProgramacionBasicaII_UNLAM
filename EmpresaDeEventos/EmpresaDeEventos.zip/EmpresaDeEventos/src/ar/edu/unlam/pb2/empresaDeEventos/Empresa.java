package ar.edu.unlam.pb2.empresaDeEventos;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Empresa {
	List<Persona> clientes = new LinkedList<Persona>();
	List<Evento> eventos = new LinkedList<Evento>();

	public void agregarCliente(Persona cliente) {
		if(!this.clientes.contains(cliente)) {			
			this.clientes.add(cliente);
		}
	}

	public void agregarEvento(Evento evento) throws EventoDuplicadoException {
		if(!this.eventos.contains(evento)) {			
			this.eventos.add(evento);		
		} else {
			throw new EventoDuplicadoException("Evento duplicado");
		}
	}

	public void agregarClienteAEvento(Persona cliente, Evento evento) throws ClienteExistenteEnEventoException {
		if(this.clientes.contains(cliente)) {
			for(Evento eventoBuscado : this.eventos) {
				if(this.eventos.contains(eventoBuscado)) {
					if(!eventoBuscado.getParticipantes().contains(cliente)) {
						if(evento instanceof Taller && eventoBuscado.getParticipantes().size() < ((Taller) evento).getMaximoDeParticipantes() ) {
							eventoBuscado.getParticipantes().add(cliente);
						} else if (evento.getClass().equals(Conferencia.class)) {
							eventoBuscado.getParticipantes().add(cliente);
						}
					} else {
						throw new ClienteExistenteEnEventoException("Cliente en evento");
					}
				}
			}
		}
		
	}

	public Evento buscarEventoPorCodigo(String codigo) {
		for(Evento eventoBuscado : this.eventos) {
			if(eventoBuscado.getCodigo() == codigo) {
				return eventoBuscado;
			}
		}
		return null;
	}

	public Boolean buscarCliente(Persona cliente, Evento evento) {
			for(Evento eventoBuscado : this.eventos) {
				if(this.eventos.contains(eventoBuscado) && eventoBuscado.getParticipantes().contains(cliente)) {
					return true;
				}
			}
		return false;
	}

	public Double obtenerTotal(Taller evento) {
		for(Evento eventoBuscado : this.eventos) {
			if(eventoBuscado.equals(evento)) {
				return eventoBuscado.getParticipantes().size() * evento.getValorPorPersona();
			}
		}
		return null;
	}

	public List<Evento> obtenerConferencias() {
		List<Evento> eventosObtenidos = new LinkedList<Evento>();
		for(Evento eventoObtenido : this.eventos) {
			if(eventoObtenido.getClass().equals(Conferencia.class)) {
				eventosObtenidos.add(eventoObtenido);
			}
		}
		return eventosObtenidos;
	}

	public Map<Evento, LinkedList<Persona>> obtenerConferenciasOrdenadasPorApellido() {
		Map<Evento, LinkedList<Persona>> personasOrdenadas = new HashMap<Evento, LinkedList<Persona>>();
			for(Evento eventoObtenido : this.eventos) {
				if(eventoObtenido.getClass().equals(Conferencia.class)) {
					Collections.sort(eventoObtenido.getParticipantes());
					personasOrdenadas.put(eventoObtenido, (LinkedList<Persona>) eventoObtenido.getParticipantes());
				}
			}
		return personasOrdenadas;
	}
	
	public List<Persona> getClientes() {
		return clientes;
	}

	public List<Evento> getEventos() {
		return eventos;
	}
}
