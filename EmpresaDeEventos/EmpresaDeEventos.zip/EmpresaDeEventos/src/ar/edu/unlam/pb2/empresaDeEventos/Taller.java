package ar.edu.unlam.pb2.empresaDeEventos;

import java.time.LocalDate;
import java.time.LocalTime;

public class Taller extends Evento {
	private Integer maximoDeParticipantes; 
	private LocalTime duracion;
	public Taller(String codigo, String nombre, LocalDate fecha, Sala sala, Persona expositor , Integer maximoDeParticipantes, LocalTime duracion) {
		super(codigo, nombre, fecha, sala, expositor);
		this.maximoDeParticipantes = maximoDeParticipantes;
		this.duracion = duracion;
	}
	@Override
	public Double getValorPorPersona() {
		return 25000.0;
	}
	public Integer getMaximoDeParticipantes() {
		return maximoDeParticipantes;
	}
	
}
