package ar.edu.unlam.pb2.empresaDeEventos;

public class EventoDuplicadoException extends Exception {
	private static final long serialVersionUID = 1L;
	public EventoDuplicadoException(String mensaje) {
		super(mensaje);
	}


}
