package ar.edu.unlam.pb2.empresaDeEventos;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Test;

public class EmpresaTest {

	@Test
	public void queSePuedanAgregar1ParticipanteALaListaDeEventos() {
		Empresa empresa = new Empresa();
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		
		empresa.agregarCliente(cliente);
		
		assertEquals(1, empresa.getClientes().size());
	}
	
	@Test
	public void queNoSePuedanAgregarDosParticipantesIguales() {
		//Evento evento = new Evento("1A", "Dia de la Madre", null, Sala.CHICA, "Carloncho");
		Empresa empresa = new Empresa();
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		Persona cliente1 = new Persona("00000", "Louis", "Brossard");
		
		empresa.agregarCliente(cliente);
		empresa.agregarCliente(cliente1);
		
		assertEquals(1, empresa.getClientes().size());
	}
	
	@Test
	public void queSePuedanAgregarUnEvento() throws EventoDuplicadoException {
		Empresa empresa = new Empresa();
		Taller evento = new Taller("1A", null, null, null, null, null, null);
		
		empresa.agregarEvento(evento);
		
		assertEquals(1, empresa.getEventos().size());
	}
	
	@Test
	public void queSoloSePuedanAgregarParticipantesPrevismenteRegistradosComoClientes() throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		Taller evento = new Taller("1A", null, null, null, null, null, null);
		
		empresa.agregarEvento(evento);
		empresa.agregarClienteAEvento(cliente, evento);
		
		assertEquals(0, empresa.getEventos().get(0).getParticipantes().size());
	}
	
	@Test (expected = EventoDuplicadoException.class)
	public void dadoQueExisteUnaEmpresaCuandoAgregoUnEventoExistenteObtengoUnaEventoDuplicadoException() throws EventoDuplicadoException {
		Empresa empresa = new Empresa();
		Taller evento = new Taller("1A", null, null, null, null, null, null);
		Taller evento1 = new Taller("1A", null, null, null, null, null, null);
		
		empresa.agregarEvento(evento);
		empresa.agregarEvento(evento1);
	}
	
	@Test 
	public void dadoQueExisteUnaEmpresaConEventosCuandoBuscoUnEventoExistentePorSuCodigoObtengoElEvento() throws EventoDuplicadoException {
		Empresa empresa = new Empresa();
		Taller evento = new Taller("1A", null, null, null, null, null, null);
		
		empresa.agregarEvento(evento);
		
		assertEquals(evento, empresa.buscarEventoPorCodigo("1A"));
	}
	
	@Test 
	public void dadoQueExisteUnaEmpresaConEventosCuandoVerificoSiUnClienteSeEncuentraEntreLosParticipantesDeUnEventoPorClienteYExisteObtengoUnResultadoPositivo() throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		Taller evento = new Taller("1A", null, null, null, null, 5, null);
		
		empresa.agregarEvento(evento);
		empresa.agregarCliente(cliente);
		empresa.agregarClienteAEvento(cliente, evento);
		
		assertTrue(empresa.buscarCliente(cliente, evento));
	}
	
	@Test (expected = ClienteExistenteEnEventoException.class)
	public void dadoQueExisteUnaEmpresaConEventosCuandoAgregoUnClienteAUnEventoDondeExisteElClienteObtengoUnaClienteExistenteEnEventoException() throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		Persona cliente1 = new Persona("00000", "Louis", "Brossard");
		Taller evento = new Taller("1A", null, null, null, null, 5, null);
		
		empresa.agregarCliente(cliente);
		empresa.agregarCliente(cliente1);
		
		empresa.agregarEvento(evento);
		empresa.agregarClienteAEvento(cliente, evento);
		empresa.agregarClienteAEvento(cliente1, evento);
	}
	
	@Test
	public void  dadoQueExisteUnaEmpresaConEventosCuandoAgregoUnClienteAUnTallerSinCupoDondeNoExisteElClienteObtengoUnResultadoFallido()throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		Persona cliente1 = new Persona("00001", "Louis", "Brossard");
		Persona cliente2 = new Persona("00002", "Louis", "Brossard");
		Taller evento = new Taller("1A", null, null, null, null, 2, null);
		
		empresa.agregarCliente(cliente);
		empresa.agregarCliente(cliente1);
		empresa.agregarCliente(cliente2);
		
		empresa.agregarEvento(evento);
		empresa.agregarClienteAEvento(cliente, evento);
		empresa.agregarClienteAEvento(cliente1, evento);
		empresa.agregarClienteAEvento(cliente2, evento);
		
		assertEquals(2, empresa.getEventos().get(0).getParticipantes().size());
	}

	@Test
	public void dadoQueExisteUnaEmpresaConEventosCuandoConsultoLaRecaudacionTodalDeUnEventoTallerCon10ParticipantesRecibo250000() throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		
		Persona cliente = new Persona("00000", "Louis", "Brossard");
		Persona cliente1 = new Persona("00001", "Louis", "Brossard");
		Persona cliente2 = new Persona("00002", "Louis", "Brossard");
		Persona cliente3 = new Persona("00003", "Louis", "Brossard");
		Persona cliente4 = new Persona("00004", "Louis", "Brossard");
		Persona cliente5 = new Persona("00005", "Louis", "Brossard");
		Persona cliente6 = new Persona("00006", "Louis", "Brossard");
		Persona cliente7 = new Persona("00007", "Louis", "Brossard");
		Persona cliente8 = new Persona("00008", "Louis", "Brossard");
		Persona cliente9 = new Persona("00009", "Louis", "Brossard");
		
		Taller evento = new Taller("1A", null, null, null, null, 10, null);
		
		empresa.agregarCliente(cliente);
		empresa.agregarCliente(cliente1);
		empresa.agregarCliente(cliente2);
		empresa.agregarCliente(cliente3);
		empresa.agregarCliente(cliente4);
		empresa.agregarCliente(cliente5);
		empresa.agregarCliente(cliente6);
		empresa.agregarCliente(cliente7);
		empresa.agregarCliente(cliente8);
		empresa.agregarCliente(cliente9);
		
		empresa.agregarEvento(evento);
		empresa.agregarClienteAEvento(cliente, evento);
		empresa.agregarClienteAEvento(cliente1, evento);
		empresa.agregarClienteAEvento(cliente2, evento);
		empresa.agregarClienteAEvento(cliente3, evento);
		empresa.agregarClienteAEvento(cliente4, evento);
		empresa.agregarClienteAEvento(cliente5, evento);
		empresa.agregarClienteAEvento(cliente6, evento);
		empresa.agregarClienteAEvento(cliente7, evento);
		empresa.agregarClienteAEvento(cliente8, evento);
		empresa.agregarClienteAEvento(cliente9, evento);
		
		assertEquals(250000.0, empresa.obtenerTotal(evento), 0.0);
	}
	
	@Test
	public void  dadoQueExisteUnaEmpresaConEventos3ConferenciasObtengoUnaListaCon3Conferencias() throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		
		Taller evento = new Taller("1A", null, null, null, null, 2, null);
		Conferencia evento1 = new Conferencia("2A", null, null, null, null);
		Conferencia evento2 = new Conferencia("3A", null, null, null, null);
		Conferencia evento3 = new Conferencia("4A", null, null, null, null);
		
		empresa.agregarEvento(evento);
		empresa.agregarEvento(evento1);
		empresa.agregarEvento(evento2);
		empresa.agregarEvento(evento3);
		
		List<Evento> eventosObtenidos = empresa.obtenerConferencias();
		
		assertEquals(3, eventosObtenidos.size());
	}
	
	@Test
	public void dadoQueExisteUnaEmpresaConEventosCuandoConsultoLosParticipantesDeConferenciasObtengoUnMapaConLasConferenciasComoClaveYUnaColeccionDeParticipantesPorConferenciaOrdenadaPorApellido() throws EventoDuplicadoException, ClienteExistenteEnEventoException {
		Empresa empresa = new Empresa();
		
		Conferencia evento1 = new Conferencia("2A", null, null, null, null);
		empresa.agregarEvento(evento1);
		Persona cliente2 = new Persona("00001", "Louis", "Brossard");		//2
		Persona cliente1 = new Persona("00000", "Louis", "Zapata");			//4
		Persona cliente3 = new Persona("00002", "Louis", "Arias");			//1
		Persona cliente4 = new Persona("00003", "Louis", "Coronado");		//3
		empresa.agregarCliente(cliente2);
		empresa.agregarCliente(cliente1);
		empresa.agregarCliente(cliente3);
		empresa.agregarCliente(cliente4);
		
		empresa.agregarClienteAEvento(cliente2, evento1);
		empresa.agregarClienteAEvento(cliente1, evento1);
		empresa.agregarClienteAEvento(cliente3, evento1);
		empresa.agregarClienteAEvento(cliente4, evento1);
		
		Conferencia evento2 = new Conferencia("3A", null, null, null, null);
		empresa.agregarEvento(evento2);
		
		Conferencia evento3 = new Conferencia("4A", null, null, null, null);
		empresa.agregarEvento(evento3);
		
		Map<Evento , LinkedList<Persona>> mapaDeEventos = empresa.obtenerConferenciasOrdenadasPorApellido();
		
		assertEquals(3, mapaDeEventos.size());
		assertEquals(4, mapaDeEventos.get(evento1).size());
		
		assertEquals("Arias", mapaDeEventos.get(evento1).get(0).getApellido());
		assertEquals("Brossard", mapaDeEventos.get(evento1).get(1).getApellido());
		assertEquals("Coronado", mapaDeEventos.get(evento1).get(2).getApellido());
		assertEquals("Zapata", mapaDeEventos.get(evento1).get(3).getApellido());
	}

}
