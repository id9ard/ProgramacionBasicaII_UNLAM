package ar.edu.unlam.pb2.cuentasBancarias;

public class Transaccion implements Comparable<Transaccion>{
	private Motivo motivo;
	private Double dineroATransferir;
	private Cuenta cuentaOrigen;
	private Cuenta cuentaDestino;
	
	private static Integer contador = 0;
	private Integer id;
	
	public Transaccion(Motivo motivo, Double dineroATransferir, Cuenta cuentaOrigen, Cuenta cuentaDestino) {
		this.id = ++contador;
		this.motivo = motivo;
		this.dineroATransferir = dineroATransferir;
		this.cuentaOrigen = cuentaOrigen;
		this.cuentaDestino = cuentaDestino;
	}

	public Integer getId() {
		return id;
	}

	@Override
	public int compareTo(Transaccion o) {
		return this.id.compareTo(o.getId());
	}

}
