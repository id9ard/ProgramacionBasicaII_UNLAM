package ar.edu.unlam.pb2.cuentasBancarias;

public enum Motivo {
	DEPOSITO, EXTRACCION, TRANSFERENCIA
}
