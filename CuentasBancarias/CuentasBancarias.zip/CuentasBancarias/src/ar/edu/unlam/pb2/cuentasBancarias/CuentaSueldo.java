package ar.edu.unlam.pb2.cuentasBancarias;

public class CuentaSueldo extends Cuenta {
	public CuentaSueldo (String cbu) {
		super(cbu);
	}
	
	@Override
	public Boolean retirarDinero(Double dineroARetirar) {
		if(super.getSaldo() >= dineroARetirar) {			
			super.setSaldo(super.getSaldo() - dineroARetirar);
			super.getTransacciones().add(new Transaccion(Motivo.EXTRACCION, dineroARetirar, null, this));
			return true; 
		}
		return false;
	}

}
