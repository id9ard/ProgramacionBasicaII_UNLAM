package ar.edu.unlam.pb2.cuentasBancarias;

public class CajaDeAhorro extends Cuenta {
	private final Integer cantidadDeRetirosSinCobrar = 5;
	private final Integer costoDelRetiro = 6;
	private Integer cantidadDeRetiros = 0;
	
	public CajaDeAhorro (String cbu) {
		super(cbu);
	}
	
	@Override
	public Boolean retirarDinero(Double dineroARetirar) {
		if(super.getSaldo() >= dineroARetirar) {
			if(cantidadDeRetiros >= cantidadDeRetirosSinCobrar && super.getSaldo() >= (dineroARetirar + costoDelRetiro)) {
				super.setSaldo(super.getSaldo() - dineroARetirar - costoDelRetiro);
				super.getTransacciones().add(new Transaccion(Motivo.EXTRACCION, dineroARetirar, null, this));
				cantidadDeRetiros++;
				return true;
			} else if(cantidadDeRetiros < cantidadDeRetirosSinCobrar) {
				super.setSaldo(super.getSaldo() - dineroARetirar);
				super.getTransacciones().add(new Transaccion(Motivo.EXTRACCION, dineroARetirar, null, this));
				cantidadDeRetiros++;
				return true;
			}
			 
		}
		return false;
	}
}
