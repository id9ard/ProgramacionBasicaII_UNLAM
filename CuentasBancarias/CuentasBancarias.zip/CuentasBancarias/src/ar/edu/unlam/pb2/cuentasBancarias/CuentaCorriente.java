package ar.edu.unlam.pb2.cuentasBancarias;

public class CuentaCorriente extends Cuenta{
	private Double cantidadEnDescubierto = 0.0;
	private Double deuda = 0.0;
	public CuentaCorriente (String cbu) {
		super(cbu);
	}
	
	public Double getCantidadEnDescubierto() {
		return cantidadEnDescubierto;
	}

	public Double getDeuda() {
		return deuda;
	}

	@Override
	public Boolean retirarDinero(Double dineroARetirar) {
		if(super.getSaldo() < dineroARetirar) {
			if(this.cantidadEnDescubierto >= dineroARetirar && super.getSaldo() == 0) {
				this.cantidadEnDescubierto -= dineroARetirar;
				this.deuda += dineroARetirar + dineroARetirar * 0.05;
				super.getTransacciones().add(new Transaccion(Motivo.EXTRACCION, dineroARetirar, null, this));
				return true;
			} else if((super.getSaldo() + this.cantidadEnDescubierto) >= dineroARetirar && super.getSaldo() > 0) {
				Double cantidadEnDescubiertoARetirar = dineroARetirar - super.getSaldo();
				this.cantidadEnDescubierto -= cantidadEnDescubiertoARetirar;
				this.deuda += cantidadEnDescubiertoARetirar + cantidadEnDescubiertoARetirar * 0.05;
				super.getTransacciones().add(new Transaccion(Motivo.EXTRACCION, dineroARetirar, null, this));
				return true;
			}
		} else if(super.getSaldo() >= dineroARetirar) {
			super.setSaldo(super.getSaldo() - dineroARetirar);
			super.getTransacciones().add(new Transaccion(Motivo.EXTRACCION, dineroARetirar, null, this));
			return true;
		}
		return false;
	}

	public Boolean establecerCantidadEnDescubierto(Double cantidadEnDescubierto) {
		this.cantidadEnDescubierto += cantidadEnDescubierto;
		return true;
	}

}
