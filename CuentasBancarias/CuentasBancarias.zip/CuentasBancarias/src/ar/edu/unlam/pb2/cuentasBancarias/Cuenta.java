package ar.edu.unlam.pb2.cuentasBancarias;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class Cuenta {
	private String cbu;
	private Double saldo = 0.0;
	private List<Transaccion>transacciones = new ArrayList<Transaccion>();
	
	public Cuenta(String cbu) {
		this.cbu = cbu;
	}
	
	public Boolean agregarDinero(Double dineroAIngresar) {
		this.saldo += dineroAIngresar;
		this.transacciones.add(new Transaccion(Motivo.DEPOSITO, dineroAIngresar, null, this));
		return true;
	}
	
	public Boolean transferirDinero(Double dineroATransferir, Cuenta cuenta) throws CuentaInexistenteException {
		if(cuenta == null) {
			throw new CuentaInexistenteException("La cuenta es null");
		}else if(this.saldo >= dineroATransferir) {
			cuenta.setSaldo(cuenta.getSaldo() + dineroATransferir);
			this.transacciones.add(new Transaccion(Motivo.TRANSFERENCIA, dineroATransferir, this, cuenta));
			return true;
		}
		return false;
	}
	
	public abstract Boolean retirarDinero(Double dineroARetirar);
	
	public Double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(Double saldo) {
		this.saldo = saldo;
	}

	public List<Transaccion> getTransacciones() {
		Collections.sort(transacciones);
		return transacciones;
	}
	
}
