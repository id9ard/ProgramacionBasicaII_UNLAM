package ar.edu.unlam.pb2.cuentasBancarias;

import static org.junit.Assert.*;

import org.junit.Test;

public class CuentaSueldoTest {

	@Test
	public void queSePuedaAgregarDinero() {
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024");
		
		assertTrue(cuentaSueldo.agregarDinero(20.0));
	}
	
	@Test
	public void queSePuedaIncrementarDineroALaCuentaDe0A20Pesos() {
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024");
		
		cuentaSueldo.agregarDinero(20.0);
		
		assertEquals(20.0, cuentaSueldo.getSaldo(), 0.1);
	}
	
	@Test
	public void queSePuedaRetirarDinero() {
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024");
		
		cuentaSueldo.agregarDinero(20.0);
		
		assertEquals(true, cuentaSueldo.retirarDinero(20.0));
	}
	
	@Test
	public void queSePuedaRetirarDineroDeLaCuenta10PesosAunSaldoInicialDe20() {
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024");
		
		cuentaSueldo.agregarDinero(20.0);
		cuentaSueldo.retirarDinero(10.0);
		
		assertEquals(10.0, cuentaSueldo.getSaldo(), 0.1);
	}

	@Test
	public void queNoSePuedaRetirarMasDineroDeLaCuentaQueElDisponible() {
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024");
		
		cuentaSueldo.agregarDinero(20.0);
		
		assertFalse(cuentaSueldo.retirarDinero(30.0));
	}
	
	@Test
	public void queSePuedaAgregarUnaTransaccionDeRetirarDinero() {
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024");
		
		cuentaSueldo.agregarDinero(200.0);
		cuentaSueldo.retirarDinero(100.0);

		assertEquals(2, cuentaSueldo.getTransacciones().size(), 0.1);
	}
	
}
