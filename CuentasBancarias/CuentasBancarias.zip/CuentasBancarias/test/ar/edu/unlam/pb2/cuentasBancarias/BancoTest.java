package ar.edu.unlam.pb2.cuentasBancarias;

import static org.junit.Assert.*;

import org.junit.Test;

public class BancoTest {

	@Test (expected = CuentaInexistenteException.class)
	public void queLanceUnaExceptionCuandoSeQuieraManipularUnaCuentaNull() throws CuentaInexistenteException{
		CuentaSueldo cuentaSueldo = new CuentaSueldo("3");
		CuentaCorriente cuentaCorriente = null;
		
		assertTrue(cuentaSueldo.transferirDinero(200.0, cuentaCorriente));
	}

}
