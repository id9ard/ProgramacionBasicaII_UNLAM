package ar.edu.unlam.pb2.cuentasBancarias;

import static org.junit.Assert.*;

import org.junit.Test;

public class CajaDeAhorroTest {

	@Test
	public void queSeCobreUnAdicionalDe6PorCientoDespuesDelQuintoRetiro() {
		CajaDeAhorro cajaDeAhorro = new CajaDeAhorro("2024");
		
		cajaDeAhorro.agregarDinero(100.0);
		
		for(int i=0; i < 6 ;i++) {
			cajaDeAhorro.retirarDinero(10.0);
		}
		
		assertEquals(34.0, cajaDeAhorro.getSaldo(), 0.1);
	}
	
	@Test
	public void queSeVerifiqueSiCuentaConSaldoDisponileAntesDeRetirarConImpuestos() {
		CajaDeAhorro cajaDeAhorro = new CajaDeAhorro("2024");
		
		cajaDeAhorro.agregarDinero(65.0);
		
		for(int i=0; i < 6 ;i++) {
			cajaDeAhorro.retirarDinero(10.0);
		}
		
		assertEquals(15.0, cajaDeAhorro.getSaldo(), 0.1);
	}
	
	@Test
	public void queSePuedaAgregarUnaTransaccionDeRetirarDinero() {
		CajaDeAhorro cajaDeAhorro = new CajaDeAhorro("2024");
		
		cajaDeAhorro.agregarDinero(200.0);
		cajaDeAhorro.retirarDinero(100.0);

		assertEquals(2, cajaDeAhorro.getTransacciones().size(), 0.1);
	}
}
