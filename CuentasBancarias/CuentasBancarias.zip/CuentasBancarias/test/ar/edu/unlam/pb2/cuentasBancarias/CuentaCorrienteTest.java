package ar.edu.unlam.pb2.cuentasBancarias;

import static org.junit.Assert.*;

import org.junit.Test;

public class CuentaCorrienteTest {

	@Test
	public void queSePuedaRetirarDinero() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.agregarDinero(20.0);
		
		assertEquals(true, cuentaCorriente.retirarDinero(20.0));
	}

	@Test
	public void queSePuedaRetirarDineroDeLaCuenta10PesosAunSaldoInicialDe20() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.agregarDinero(20.0);
		cuentaCorriente.retirarDinero(10.0);
		
		assertEquals(10.0, cuentaCorriente.getSaldo(), 0.1);
	}
	
	@Test
	public void queSePuedaEstablecerUnaCantidadEnDescubierto() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		assertTrue(cuentaCorriente.establecerCantidadEnDescubierto(150.0));
	}
	
	@Test
	public void queIncrementeLaCantidadEnDescubiertoEnLaCUentaA150() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.establecerCantidadEnDescubierto(150.0);
		
		assertEquals(150.0, cuentaCorriente.getCantidadEnDescubierto(), 0.1);
	}
	
	@Test
	public void queSePuedaRetirarCantidadEnDescubiertoCon0DeSaldoY150EnDescubierto() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.establecerCantidadEnDescubierto(150.0);
		cuentaCorriente.retirarDinero(50.0);
		
		assertEquals(100.0, cuentaCorriente.getCantidadEnDescubierto(), 0.1);
	}
	
	@Test
	public void queSeCobreUn5PorCientoDelRetiroEnDescubiertoConSaldo0() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.establecerCantidadEnDescubierto(200.0);
		cuentaCorriente.retirarDinero(100.0);
		
		assertEquals(105.0, cuentaCorriente.getDeuda(), 0.1);
	}
	
	@Test
	public void queSeCobreUn5PorCientoDelRetiroEnDescubiertoConSaldoMauorACero() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.agregarDinero(100.0);
		cuentaCorriente.establecerCantidadEnDescubierto(150.0);
		cuentaCorriente.retirarDinero(200.0);
		
		assertEquals(105.0, cuentaCorriente.getDeuda(), 0.1);
	}
	
	@Test
	public void queSePuedaTransferirDineroAOTraCuenta() throws CuentaInexistenteException {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024"); 
		
		cuentaCorriente.agregarDinero(50.0);
		
		assertTrue(cuentaCorriente.transferirDinero(20.0, cuentaSueldo));
	}
	
	@Test
	public void queSePuedaTransferir50PesosDeCuentaCorrienteACuentaSueldoConSaldoInicial0() throws CuentaInexistenteException {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024"); 
		
		cuentaCorriente.agregarDinero(100.0);
		cuentaCorriente.transferirDinero(50.0, cuentaSueldo);
		
		assertEquals(50.0, cuentaSueldo.getSaldo(), 0.1);
	}
	
	@Test
	public void queNoSePuedaTransferirSiElSaldoEsMenorAlMontoATransferir() throws CuentaInexistenteException {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		CuentaSueldo cuentaSueldo = new CuentaSueldo("2024"); 
		
		cuentaCorriente.agregarDinero(100.0);
		cuentaCorriente.transferirDinero(150.0, cuentaSueldo);
		
		assertEquals(0.0, cuentaSueldo.getSaldo(), 0.1);
	}
	
	@Test
	public void queSePuedaAgregarUnaTransaccionDeAgregarDinero() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.agregarDinero(100.0);

		assertEquals(1, cuentaCorriente.getTransacciones().size(), 0.1);
	}
	
	@Test
	public void queSePuedaAgregarUnaTransaccionDeRetirarDinero() {
		CuentaCorriente cuentaCorriente = new CuentaCorriente("2024");
		
		cuentaCorriente.agregarDinero(200.0);
		cuentaCorriente.retirarDinero(100.0);

		assertEquals(2, cuentaCorriente.getTransacciones().size(), 0.1);
	}

}
