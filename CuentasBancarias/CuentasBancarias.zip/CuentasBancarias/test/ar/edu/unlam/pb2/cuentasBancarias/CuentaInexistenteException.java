package ar.edu.unlam.pb2.cuentasBancarias;

public class CuentaInexistenteException extends NullPointerException {
	
	private static final long serialVersionUID = 1L;
	public CuentaInexistenteException(String mensaje) {
		super(mensaje);
	}
}
