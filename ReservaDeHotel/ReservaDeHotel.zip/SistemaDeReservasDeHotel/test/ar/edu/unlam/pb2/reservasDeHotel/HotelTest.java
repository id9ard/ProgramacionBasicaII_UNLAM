package ar.edu.unlam.pb2.reservasDeHotel;

import static org.junit.Assert.*;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import org.junit.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;

public class HotelTest {

	@Test
	public void queSePuedaAgregarUnaHabitacionEstandarAlSistema() {
		Hotel hotel = new Hotel();
		Estandar estandar = new Estandar("1", 2); 
		
		hotel.agregarHabitacion(estandar);
		
		assertEquals(1, hotel.getHabitaciones().size());
	}
	
	@Test
	public void queSePuedarealizarUnaReservaEnUnaHabitacionEstandarDisponible() throws HabitacionInexistenteException, HabitacionOcupadaException {
		Hotel hotel = new Hotel();
		Estandar estandar = new Estandar("1", 2);
		Cliente cliente = new Cliente("Louis", "12345");
		
		Date fechaInicial = new Date();
		Date fechaFin = new Date(fechaInicial.getTime() + 5 * 24 * 60 * 60 * 1000);
		
		Reserva reserva = new Reserva(cliente, "1", fechaInicial, fechaFin);
		
		hotel.agregarHabitacion(estandar);
		hotel.agregarReserva(reserva);
		
		assertEquals(1, hotel.getReservas().size());
	}
	
	@Test
	public void queSePuedaCancelarUnaReserva() throws HabitacionInexistenteException, HabitacionOcupadaException {
		Hotel hotel = new Hotel();
		Estandar estandar = new Estandar("1", 2);
		Cliente cliente = new Cliente("Louis", "12345");
		
		Date fechaInicial = new Date();
		Date fechaFin = new Date(fechaInicial.getTime() + 5 * 24 * 60 * 60 * 1000);
		
		Reserva reserva = new Reserva(cliente, "1", fechaInicial, fechaFin);
		
		hotel.agregarHabitacion(estandar);
		hotel.agregarReserva(reserva);
		hotel.cancelarReserva(reserva);
		
		assertEquals(0, hotel.getReservas().size());
	}
	
	@Test (expected = HabitacionInexistenteException.class)
	public void queLanceUnaExcepcionSiSeIntentaReservarUnaHabitacionInexistente() throws HabitacionInexistenteException, HabitacionOcupadaException {
		Hotel hotel = new Hotel();
		Estandar estandar = new Estandar("1", 2);
		Cliente cliente = new Cliente("Louis", "12345");
		
		Date fechaInicial = new Date();
		Date fechaFin = new Date(fechaInicial.getTime() + 5 * 24 * 60 * 60 * 1000);
		
		Reserva reserva = new Reserva(cliente, "2", fechaInicial, fechaFin);
		
		hotel.agregarHabitacion(estandar);
		hotel.agregarReserva(reserva);
	}

	@Test (expected = HabitacionOcupadaException.class)
	public void queLanceUnaExcepcionSiLaHabitacionYaEstaOcupada() throws HabitacionInexistenteException, HabitacionOcupadaException {
		Hotel hotel = new Hotel();
		Estandar estandar = new Estandar("1", 2);
		Cliente cliente = new Cliente("Louis", "12345");
		
		Date fechaInicial = new Date();
		Date fechaFin = new Date(fechaInicial.getTime() + 5 * 24 * 60 * 60 * 1000);
		
		Reserva reserva = new Reserva(cliente, "1", fechaInicial, fechaFin);
		
		hotel.agregarHabitacion(estandar);
		hotel.agregarReserva(reserva);
		hotel.agregarReserva(reserva);
	}
	
	@Test
	public void queSePuedaAgregarUnaHabitacionSuiteAlSistema() throws HabitacionInexistenteException, HabitacionOcupadaException {
		Hotel hotel = new Hotel();
		Suite suite = new Suite("1", 2, true, true, 3);
		Cliente cliente = new Cliente("Louis", "12345");
		
		Date fechaInicial = new Date();
		Date fechaFin = new Date(fechaInicial.getTime() + 5 * 24 * 60 * 60 * 1000);
		
		Reserva reserva = new Reserva(cliente, "1", fechaInicial, fechaFin);
		
		hotel.agregarHabitacion(suite);
		hotel.agregarReserva(reserva);
		
		assertEquals(1, hotel.getReservas().size());

	}
	
	@Test
	public void quePuedaDevolverUnaReservaQueCoincidaConElRangoDeFechas() throws HabitacionInexistenteException, HabitacionOcupadaException {
		Hotel hotel = new Hotel();
		Estandar estandar1 = new Estandar("1", 2);
		Estandar estandar2 = new Estandar("2", 2);
		Estandar estandar3 = new Estandar("3", 2);
		
		Cliente cliente = new Cliente("Louis", "12345");
		
		Date fechaInicial = new Date();
		
		Date fechaFin1 = new Date(fechaInicial.getTime() + 1 * 24 * 60 * 60 * 1000);
		Date fechaFin2 = new Date(fechaInicial.getTime() + 5 * 24 * 60 * 60 * 1000);
		Date fechaFin3 = new Date(fechaInicial.getTime() + 10 * 24 * 60 * 60 * 1000);
		
		Reserva reserva1 = new Reserva(cliente, "1", fechaInicial, fechaFin1);
		Reserva reserva2 = new Reserva(cliente, "2", fechaInicial, fechaFin2);
		Reserva reserva3 = new Reserva(cliente, "3", fechaInicial, fechaFin3);
		
		hotel.agregarHabitacion(estandar1);
		hotel.agregarHabitacion(estandar2);
		hotel.agregarHabitacion(estandar3);
		
		hotel.agregarReserva(reserva1);
		hotel.agregarReserva(reserva2);
		hotel.agregarReserva(reserva3);
		
		Date fechaDeInicioABuscar = new Date();
		Date fechaDeFinABuscar = new Date(fechaInicial.getTime() + 1 * 24 * 60 * 60 * 1000);
		
		List<Reserva> reservas = hotel.consultarReservaEntreDosFechas(fechaDeInicioABuscar, fechaDeFinABuscar);
		
		assertEquals(1, reservas.size());
		
	}
	
}
