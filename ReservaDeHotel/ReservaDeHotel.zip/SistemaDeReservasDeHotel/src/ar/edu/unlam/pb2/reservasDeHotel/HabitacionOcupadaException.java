package ar.edu.unlam.pb2.reservasDeHotel;

public class HabitacionOcupadaException extends Exception {
	private static final long serialVersionUID = 1L;
	public HabitacionOcupadaException(String mensaje) {
		super(mensaje);
	}

}
