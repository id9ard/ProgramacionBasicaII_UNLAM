package ar.edu.unlam.pb2.reservasDeHotel;

public class HabitacionInexistenteException extends Exception {

	private static final long serialVersionUID = 1L;
	public HabitacionInexistenteException(String mensaje) {
		super(mensaje);
	}
}
