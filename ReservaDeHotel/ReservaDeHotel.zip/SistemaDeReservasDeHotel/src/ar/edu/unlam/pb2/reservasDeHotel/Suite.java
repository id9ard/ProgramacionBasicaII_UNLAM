package ar.edu.unlam.pb2.reservasDeHotel;

public class Suite extends Habitacion{
	 private boolean tieneJacuzzi; 
	 private  boolean tieneServicioMayordormo;
	 private Integer numeroHabitaciones;

	public Suite(String numeroDeHabitacion, Integer capacidad, boolean tieneJacuzzi, boolean tieneServicioMayordormo, Integer numeroHabitaciones) {
		super(numeroDeHabitacion, capacidad);
		this.tieneJacuzzi = tieneJacuzzi;
		this.tieneServicioMayordormo = tieneServicioMayordormo;
		this.numeroHabitaciones = numeroHabitaciones;
	}

	@Override
	public Double getPrecioPorNoche() {
		return 1000.0;
	}

}
