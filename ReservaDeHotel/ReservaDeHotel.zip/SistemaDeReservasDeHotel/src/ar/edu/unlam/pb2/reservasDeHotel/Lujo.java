package ar.edu.unlam.pb2.reservasDeHotel;

public class Lujo extends Habitacion{
	private boolean incluyeRopaCama; 
	 private  boolean tieneAccesoAGymnasio;

	public Lujo(String numeroDeHabitacion, Integer capacidad, boolean incluyeRopaCama, boolean tieneAccesoAGymnasio) {
		super(numeroDeHabitacion, capacidad);
		this.incluyeRopaCama = incluyeRopaCama;
		this.tieneAccesoAGymnasio = tieneAccesoAGymnasio;
	}

	@Override
	public Double getPrecioPorNoche() {
		return 400.0;
	}
	
}
