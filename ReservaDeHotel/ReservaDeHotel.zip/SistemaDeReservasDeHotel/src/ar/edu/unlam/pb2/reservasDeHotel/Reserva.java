package ar.edu.unlam.pb2.reservasDeHotel;

import java.util.Date;

public class Reserva {
	private Cliente cliente;
	private String numeroHabitacion;
	private Date fechaInicio;
	private Date fechaFin;
	public Reserva(Cliente cliente, String numeroHabitacion, Date fechaInicio, Date fechaFin) {
		super();
		this.cliente = cliente;
		this.numeroHabitacion = numeroHabitacion;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public String getNumeroHabitacion() {
		return numeroHabitacion;
	}
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}

}
