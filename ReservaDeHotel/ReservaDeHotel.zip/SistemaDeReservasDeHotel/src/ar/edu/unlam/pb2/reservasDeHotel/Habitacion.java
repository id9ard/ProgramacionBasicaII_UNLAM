package ar.edu.unlam.pb2.reservasDeHotel;

public abstract class Habitacion {
	private String numeroDeHabitacion;
	private Integer capacidad;
	private Double precioPorNoche;
	
	private boolean estaDisponible;
	
	public Habitacion(String numeroDeHabitacion, Integer capacidad) {

		this.numeroDeHabitacion = numeroDeHabitacion;
		this.capacidad = capacidad;
		this.estaDisponible = true;
	}
	public String getNumeroDeHabitacion() {
		return numeroDeHabitacion;
	}
	public Integer getCapacidad() {
		return capacidad;
	}
	
	public boolean isEstaDisponible() {
		return estaDisponible;
	}
	public void setEstaDisponible(boolean estaDisponible) {
		this.estaDisponible = estaDisponible;
	}
	
	public abstract Double getPrecioPorNoche();
}
