package ar.edu.unlam.pb2.reservasDeHotel;

public class Estandar extends Habitacion{

	public Estandar(String numeroDeHabitacion, Integer capacidad) {
		super(numeroDeHabitacion, capacidad);
	}

	@Override
	public Double getPrecioPorNoche() {
		return 150.0;
	}

}
