package ar.edu.unlam.pb2.reservasDeHotel;

import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class Hotel {
	private Map<String,Habitacion> habitaciones = new HashMap<String,Habitacion>();
	private List<Reserva> reservas = new LinkedList<Reserva>();

	public void agregarHabitacion(Habitacion habitacion) {
		this.habitaciones.put(habitacion.getNumeroDeHabitacion(), habitacion);
	}

	public Map<String, Habitacion> getHabitaciones() {
		return habitaciones;
	}
	
	public void agregarReserva(Reserva reserva) throws HabitacionInexistenteException, HabitacionOcupadaException {
		Habitacion habitacionObtenida = obtenerHabitacion(reserva.getNumeroHabitacion());
		if(habitacionObtenida != null) {
			if(!this.reservas.contains(habitacionObtenida.getNumeroDeHabitacion()) &&
					consultarReservaEntreDosFechas(reserva.getFechaInicio(), reserva.getFechaFin()).isEmpty()) {				
				this.reservas.add(reserva);
				habitacionObtenida.setEstaDisponible(false);
			} else {
				throw new HabitacionOcupadaException("La habitacion ya esta ocupada");
			}
		} else {
			throw new HabitacionInexistenteException("La habitacion no existe");
		}
	}

	public List<Reserva> getReservas() {
		return reservas;
	}
	
	private Habitacion obtenerHabitacion(String numeroDeHabitacion) {
		for(Entry<String, Habitacion> habitacionObtenida : this.habitaciones.entrySet()) {
			if(habitacionObtenida.getKey() == numeroDeHabitacion) {
				return habitacionObtenida.getValue();
			}
		}
		return null;
	}

	public void cancelarReserva(Reserva reserva) {
		Habitacion habitacionObtenida = obtenerHabitacion(reserva.getNumeroHabitacion());
		if(habitacionObtenida != null) {			
			this.reservas.remove(reserva);
			habitacionObtenida.setEstaDisponible(false);
		}
	}

	public List<Reserva> consultarReservaEntreDosFechas(Date fechaUno, Date fechaDos) {
		List<Reserva> reservasObtenidas = new LinkedList<Reserva>();
		for(Reserva reservaObtenida : this.reservas) {
			if(reservaObtenida.getFechaInicio().getTime() == fechaUno.getTime() &&
					reservaObtenida.getFechaFin().getTime() == fechaDos.getTime()) {
				reservasObtenidas.add(reservaObtenida);
			}
		}
		return reservasObtenidas;
	}
	
}
